package com.example.intercom.controller;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.example.intercom.R;
import com.example.intercom.model.Usuario;
import com.google.android.material.textfield.TextInputEditText;
public class Login extends AppCompatActivity {
    //ATRIBUTOS DE LA CLASE
    TextInputEditText correo;
    TextInputEditText clave;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        //Casteamos los objetos con los de la vista
        this.correo =findViewById(R.id.TxtCorreoLogin);
        this.clave = findViewById(R.id.TxtClaveLogin);
    }
    public void onClick(View view){
        if(view.getId() == R.id.BtnIniciarLogin){
            //INSTANCIO UN OBJETO DE TIPO USUARIO
            Usuario object = new Usuario();
            //INICIALIZAR LOS DATOS DEL ISUARIO
            object.setCorreo(correo.getText().toString());
            object.setClave(clave.getText().toString());
            //CONDICION PARA EVALUAR LA RESPUESTA DEL MODELO
            if (object.login(this) == true){
                Toast toast1 = Toast.makeText(getApplicationContext(),
                        "LAS CREDENCIALES SON CORRECTAS", Toast.LENGTH_SHORT);
                toast1.show();
                //finalizo el registro
                Intent viewLogin = new Intent(Login.this, Home.class);
                startActivity(viewLogin);
                finish();
            }else{
                Toast toast1 = Toast.makeText(getApplicationContext(),
                        "LAS CREDENCIALES QUE USTED ESTÀ INTENTANDO INGRESAR SON ERRONEAS,PORFAVOR CREE UNA CUENTA.", Toast.LENGTH_SHORT);
                toast1.show();
            }
        }else if (view.getId() == R.id.BtnCrearCuentaLogin){
            //finalizo el registro
            Intent viewRegister = new Intent(Login.this, UserRegister.class);
            startActivity(viewRegister);
        }
    }
}
